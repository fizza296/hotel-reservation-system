const connection = require('./db');

// Insert data into the 'users' table
const insertUserQuery = `
  INSERT INTO Users (username, email, password) 
  VALUES ('Fizza (perfect)', 'fizza@perfection.com', '10');
`;

connection.query(insertUserQuery, (err, results) => {
  if (err) {
    console.error('Error inserting data: ', err);
  } else {
    console.log('Data inserted successfully', results);
  }
  // Close the connection
  connection.end();
});
